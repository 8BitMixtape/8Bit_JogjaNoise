#line 1 "/home/dusjagr/Arduino/Yogya_Noise/Jarmageddon_v2_yogya/Jarmageddon_v2_yogya.ino"
#line 1 "/home/dusjagr/Arduino/Yogya_Noise/Jarmageddon_v2_yogya/Jarmageddon_v2_yogya.ino"
#include <Arduino.h>
#line 1 "/Volumes/LOCALBRAIN/Projects/AVR/8BitMixtapeNeo/8BitMixtapeNEO-Experiment/Moff_Jarmageddon/Moff_Jarmageddon.ino"
#line 1 "/Volumes/LOCALBRAIN/Projects/AVR/8BitMixtapeNeo/8BitMixtapeNEO-Experiment/Moff_Jarmageddon/Moff_Jarmageddon.ino"
/*
         Jarmaggedøn
      Møffenzeef Mødular
        Røss Fish 2017
  http://moffenzeefmodular.com
         CC-BY-NC-SA
  Based on "Audio Sample Player"
      By: David Johnson-Davies
  http://www.technoblogy.com/show?QBB
          CC BY 4.0
*/

#include <avr/pgmspace.h>
#include <avr/power.h>

unsigned int Acc[] {0, 0};
unsigned int Note = 0;
unsigned int Note1 = 0;

int potRaw = 0;
int CVraw = 0;
int pitch = 0;
int modulate = 0;
int math = 0;

#line 26 "/Volumes/LOCALBRAIN/Projects/AVR/8BitMixtapeNeo/8BitMixtapeNEO-Experiment/Moff_Jarmageddon/Moff_Jarmageddon.ino"
void setup();
#line 45 "/Volumes/LOCALBRAIN/Projects/AVR/8BitMixtapeNeo/8BitMixtapeNEO-Experiment/Moff_Jarmageddon/Moff_Jarmageddon.ino"
void loop();
#line 26 "/Volumes/LOCALBRAIN/Projects/AVR/8BitMixtapeNeo/8BitMixtapeNEO-Experiment/Moff_Jarmageddon/Moff_Jarmageddon.ino"
void setup() {
    clock_prescale_set(clock_div_2); //NO PROCESSOR PRESCALE

  // Enable 64 MHz PLL and use as source for Timer1
  PLLCSR = 1 << PCKE | 1 << PLLE;

  // Set up Timer/Counter1 for PWM output
  TIMSK = 0;                              // Timer interrupts OFF
  TCCR1 = 1 << PWM1A | 2 << COM1A0 | 1 << CS10; // PWM A, clear on match, 1:1 prescale

  // Set up Timer/Counter0 for 8kHz interrupt to output samples.
  TCCR0A = 3 << WGM00;                    // Fast PWM
  TCCR0B = 1 << WGM02 | 2 << CS00;        // 1/8 prescale
  TIMSK = 1 << OCIE0A;                    // Enable compare match

  pinMode(1, OUTPUT);
  pinMode(0, OUTPUT);
}

void loop() {

  potRaw = analogRead(A1)>>3;
  CVraw = analogRead(A2)>>2;

  math = potRaw + CVraw;
  math = max(math, 0);
  math = min(math, 1023);
  

  Note = map(math, 0, 1023, 60000, 10);
  Note1 = map(math, 0, 1023, 100, -100);
  modulate = map(math, 0, 1023, 32, -32);

  OCR0A = map(math, 0, 1023, 255, 20);
  
  digitalWrite(0, CVraw>>2); 
}

// Sample interrupt
ISR(TIMER0_COMPA_vect) {
  Acc[0] = Acc[0] + Note;
  Acc[1] = Acc[1] + Note1;
  OCR1A = ((((char)Acc[0] ^ Acc[1]) >> 8 & 0x80) ^ modulate); //
  
}

